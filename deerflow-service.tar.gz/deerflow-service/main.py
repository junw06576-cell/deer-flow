from fastapi import FastAPI
from routers.analysis import router as analysis_router

app = FastAPI(
    title="DeerFlow Service",
    description="为 TFS-BUDDY 提供需求分析能力。当前场景：req-analysis（需求自动质控）。",
    version="2.0.0",
)

# 需求质控路由
app.include_router(analysis_router)


@app.get("/api/v1/health")
async def health_check():
    return {
        "status": "ok",
        "service": "deerflow-service",
        "version": "2.0.0",
        "endpoints": {
            "submit_analysis": "POST /api/v1/analysis",
            "poll_result": "GET /api/v1/analysis/{task_id}",
        },
    }
